__author__ = "Oleg Butovich"
__copyright__ = "(c) Oleg Butovich 2013-2024"
__version__ = "2.2.0"
__license__ = "MIT"

from .core import *  # noqa
